import React, { Component } from 'react';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';

import Navegacao from './components/Navegação';
import Home from './components/Home';
import Servicos from './components/Servicos';
import Contactos from './components/Contactos';

class App extends Component{

  render(){
    return(
      <Router>
        <div>
          <Navegacao />

          <switch>
            <Route exact path="/">
              <Home />
            </Route>

            <Route path="/servicos">
              <Servicos />
            </Route>

            <Route path="/contactos">
              <Contactos />
            </Route>
          </switch>
        </div>
      </Router>
    )
  }
}

export default App;
