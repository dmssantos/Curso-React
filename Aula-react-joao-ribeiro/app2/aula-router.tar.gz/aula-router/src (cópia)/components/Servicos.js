import React from 'react';

const Servicos = () => {
    return(
        <div>
            <h1>Servicos</h1>
        </div>
    )
}

export default Servicos;