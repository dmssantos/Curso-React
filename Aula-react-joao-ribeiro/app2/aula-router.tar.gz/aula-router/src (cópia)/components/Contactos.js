import React from 'react';

const Contactos = () => {
    return(
        <div>
            <h1>Contactos</h1>
        </div>
    )
}

export default Contactos;